
<p align="center"><img src="https://images.firstpost.com/wp-content/uploads/2020/07/jio-tvplus-1280.jpg" width="180" height="100"></p>

<h1 align='center'>✯ JɪᴏTV Pʟᴀʏ Termux ✯</h1>

<!-- DO NOT EDIT FILE AND ADD YOU NAME HERE AND PUBLISH -->
<!-- © 2021 TechieSneh -->

<h4 align='center'>📺 The PHP Script For Grabb Streaming Links and Play it , This Works Only on Any Terminal & Termux Through LocalHost <br><br>🌟 Start This Repositry Befor Copying 😎<br>😠 Don't Remove Creadits<br>Don't Edit This Script 😈<br><br>Put Your Own Token In This Script</h4>
<br>

<h2>😇 Features :</h2>

- HQ Streaming Free of Cost <br>
- Will Works In 250, 400, 600, 800 in this Gives Qualities
- Web Play Supports
- TiviMate or PC Users can Also Use This [JIOTV PlayList.m3u](https://github.com/techiesneh/Sneh-JioTv-Termux/blob/main/sneh-jiotv/sneh-playlist.m3u)


<br>
<h2>🍁 How To Setup : </h2>

#### ♢ Method 1 :

• First Download Termux From Playstore <br>

  ```py
 https://www.apkmirror.com/apk/fredrik-fornwall/termux/termux-0-95-release/termux-0-95-android-apk-download/download/?forcebaseapk 

  ```

• Then Run This Commands in Termux <br>
• Just Copy & Paste One by One <br>

```py
pkg update && upgrade
```

```py
pkg install git php
```

```py
git clone https://github.com/techiesneh/Sneh-JioTv-Termux.git
```

```py
php -S localhost:8585 -t $HOME/Sneh-JioTv-Termux
```
  
  
• Put Your Mobile Number with 91 & Password in Below Link <br>

```py
http://localhost:8585/sneh-jiotv/acc.php?user=NUMBER&pass=PASSWORD
```

#### 😛 Genrate ssoToken Here :

- For This You Need JioID Number and Password

[Jio Login Page] (http://jiologin.unaux.com/)
 
- `user` = Username / Mobile No.
- `pass` = Password

<br>

• Now Run Your Local JioTV 😍<br>

  ```py
 http://localhost:8585/sneh-jiotv/index.php
  ```

• Open [JIOTV Termux PlayList.m3u](https://raw.githubusercontent.com/techiesneh/Sneh-JioTv-Termux/main/sneh-jiotv/playlist.m3u) in any IPTV Player . You Will See all Channels List <br>

• Click On Channel and Play <br>

#### ♢ Method 2 :

• In Player Put Links Format Like Below

  ```py
  [+] - http://localhost:8585/sneh-jiotv/jioo.php?c=Channel_Name&q=Quality
  
  [+] - http://localhost:8585/sneh-jiotv/jioo.php?c=And_Pictures_HD&q=800
  
  ```
  
   ♢ This Script is free for USE and Modify</b><br><br>

<h2>🚸 Warnings :</h2>

- This is Just For Educational Purpose
- DO NOT Sell this Script, This is 💯% Free

<h3>🤗 Meet Me : </h3>

• For any Support Join Our Group [Techie Sneh](https://t.me/techiesneh007)<br>
• Or Contact at [techiesneh@protonmail.com](mailto:techiesneh@protonmail.com)

<br>


---
<h4 align='center'>© 2021 Techie Sneh</h4>

<!-- DO NOT REMOVE THIS CREDIT 🤬 🤬 -->










